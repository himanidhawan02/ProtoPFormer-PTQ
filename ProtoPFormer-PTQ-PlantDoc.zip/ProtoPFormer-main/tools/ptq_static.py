"""Calibrated per-module static INT8 PTQ for the original ProtoPFormer.

This is a hybrid PTQ path: nn.Linear and nn.Conv2d layers are converted to
PyTorch CPU quantized operators. Activations are quantized using fixed,
per-module calibration ranges. Unsupported/custom operations (including
prototype distance/similarity operations, attention softmax and LayerNorm)
remain FP32. Outputs are dequantized at each module boundary so the original
ProtoPFormer computation graph and prototype logic remain unchanged.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from typing import Dict, Iterable, Optional, Tuple, Type

import torch
import torch.nn as nn
try:
    import torch.ao.nn.quantized as nnq
except ImportError:  # PyTorch 1.8 compatibility
    import torch.nn.quantized as nnq


# Keep the final class-logit projections in FP32 to avoid quantizing logits.
FP32_MODULE_NAMES = frozenset(("last_layer", "last_layer_global"))


@dataclass
class RangeStats:
    input_min: float = math.inf
    input_max: float = -math.inf
    output_min: float = math.inf
    output_max: float = -math.inf
    calls: int = 0

    @staticmethod
    def _finite_minmax(value: torch.Tensor) -> Optional[Tuple[float, float]]:
        if not isinstance(value, torch.Tensor) or value.numel() == 0:
            return None
        data = value.detach()
        if data.is_quantized:
            data = data.dequantize()
        data = data.float()
        finite = data[torch.isfinite(data)]
        if finite.numel() == 0:
            return None
        return float(finite.min().item()), float(finite.max().item())

    def update_input(self, value: torch.Tensor) -> None:
        result = self._finite_minmax(value)
        if result is not None:
            self.input_min = min(self.input_min, result[0])
            self.input_max = max(self.input_max, result[1])

    def update_output(self, value: torch.Tensor) -> None:
        result = self._finite_minmax(value)
        if result is not None:
            self.output_min = min(self.output_min, result[0])
            self.output_max = max(self.output_max, result[1])


def _activation_qparams(min_value: float, max_value: float) -> Tuple[float, int]:
    """Affine quint8 activation qparams with the real interval including zero."""
    if not math.isfinite(min_value) or not math.isfinite(max_value):
        raise ValueError("Activation calibration range is not finite.")
    lo = min(float(min_value), 0.0)
    hi = max(float(max_value), 0.0)
    if hi - lo < 1e-12:
        return 1.0, 0
    scale = (hi - lo) / 255.0
    zero_point = int(round(-lo / scale))
    zero_point = max(0, min(255, zero_point))
    return float(scale), zero_point


def _per_channel_qweight(weight: torch.Tensor) -> torch.Tensor:
    """Symmetric per-output-channel int8 quantization for Linear/Conv2d weights."""
    weight = weight.detach().cpu().float().contiguous()
    if weight.ndim < 2:
        raise ValueError(f"Expected a rank >= 2 weight tensor, got {weight.shape}.")
    flattened = weight.reshape(weight.shape[0], -1)
    max_abs = flattened.abs().amax(dim=1)
    scales = (max_abs / 127.0).clamp_min(1e-8)
    zero_points = torch.zeros_like(scales, dtype=torch.long)
    return torch.quantize_per_channel(
        weight, scales, zero_points, axis=0, dtype=torch.qint8
    )


class _StaticPTQBase(nn.Module):
    """Quantize input, run a quantized CPU operator, then dequantize output."""

    def __init__(self, input_scale: float, input_zero_point: int):
        super().__init__()
        self.input_scale = float(input_scale)
        self.input_zero_point = int(input_zero_point)

    def _quantize_input(self, value: torch.Tensor) -> torch.Tensor:
        if not isinstance(value, torch.Tensor):
            raise TypeError("PTQ-wrapped modules expect a Tensor input.")
        if value.is_quantized:
            value = value.dequantize()
        if value.device.type != "cpu":
            raise RuntimeError(
                "Static PTQ modules use PyTorch CPU quantized kernels. "
                "Move the exported model and its inputs to CPU."
            )
        return torch.quantize_per_tensor(
            value.detach().float().contiguous(),
            self.input_scale,
            self.input_zero_point,
            torch.quint8,
        )


class PTQLinear(_StaticPTQBase):
    def __init__(self, source: nn.Linear, stats: RangeStats):
        in_scale, in_zp = _activation_qparams(stats.input_min, stats.input_max)
        out_scale, out_zp = _activation_qparams(stats.output_min, stats.output_max)
        super().__init__(in_scale, in_zp)
        self.out_scale = float(out_scale)
        self.out_zero_point = int(out_zp)
        self.in_features = source.in_features
        self.out_features = source.out_features
        self.quantized_op = nnq.Linear(
            source.in_features,
            source.out_features,
            bias_=source.bias is not None,
            dtype=torch.qint8,
        )
        qweight = _per_channel_qweight(source.weight)
        bias = None if source.bias is None else source.bias.detach().cpu().float()
        self.quantized_op.set_weight_bias(qweight, bias)
        self.quantized_op.scale = self.out_scale
        self.quantized_op.zero_point = self.out_zero_point

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        quantized_input = self._quantize_input(value)
        return self.quantized_op(quantized_input).dequantize()


class PTQConv2d(_StaticPTQBase):
    def __init__(self, source: nn.Conv2d, stats: RangeStats):
        if source.padding_mode != "zeros":
            raise ValueError(
                f"Only zero-padding Conv2d is supported, got {source.padding_mode}."
            )
        in_scale, in_zp = _activation_qparams(stats.input_min, stats.input_max)
        out_scale, out_zp = _activation_qparams(stats.output_min, stats.output_max)
        super().__init__(in_scale, in_zp)
        self.out_scale = float(out_scale)
        self.out_zero_point = int(out_zp)
        self.in_channels = source.in_channels
        self.out_channels = source.out_channels
        self.quantized_op = nnq.Conv2d(
            source.in_channels,
            source.out_channels,
            source.kernel_size,
            stride=source.stride,
            padding=source.padding,
            dilation=source.dilation,
            groups=source.groups,
            bias=source.bias is not None,
            padding_mode="zeros",
            dtype=torch.qint8,
        )
        qweight = _per_channel_qweight(source.weight)
        bias = None if source.bias is None else source.bias.detach().cpu().float()
        self.quantized_op.set_weight_bias(qweight, bias)
        self.quantized_op.scale = self.out_scale
        self.quantized_op.zero_point = self.out_zero_point

    def forward(self, value: torch.Tensor) -> torch.Tensor:
        quantized_input = self._quantize_input(value)
        return self.quantized_op(quantized_input).dequantize()


def choose_quantized_engine(requested: Optional[str] = None) -> str:
    supported = list(torch.backends.quantized.supported_engines)
    if requested:
        if requested not in supported:
            raise RuntimeError(
                f"Requested quantized engine {requested!r} is unsupported. "
                f"Available: {supported}"
            )
        engine = requested
    else:
        engine = next((e for e in ("x86", "fbgemm", "onednn", "qnnpack") if e in supported), None)
        if engine is None:
            raise RuntimeError(f"No supported PyTorch quantized engine found: {supported}")
    torch.backends.quantized.engine = engine
    return engine


def calibrate_module_ranges(
    model: nn.Module,
    calibration_loader: Iterable,
    device: torch.device,
    max_batches: int = 32,
    modules_to_quantize: Tuple[str, ...] = ("linear", "conv2d"),
) -> Dict[str, RangeStats]:
    """Run representative images through FP32 model and collect per-module min/max."""
    wanted_types = []
    if "linear" in modules_to_quantize:
        wanted_types.append(nn.Linear)
    if "conv2d" in modules_to_quantize:
        wanted_types.append(nn.Conv2d)
    if not wanted_types:
        raise ValueError("Select at least one supported module type: linear/conv2d.")

    stats: Dict[str, RangeStats] = {}
    handles = []

    for name, module in model.named_modules():
        if name and name not in FP32_MODULE_NAMES and isinstance(module, tuple(wanted_types)):
            # Skip non-zero padding Conv2d rather than failing midway through export.
            if isinstance(module, nn.Conv2d) and module.padding_mode != "zeros":
                continue
            stat = RangeStats()
            stats[name] = stat

            def pre_hook(_module, inputs, _name=name, _stats=stat):
                if inputs and isinstance(inputs[0], torch.Tensor):
                    _stats.update_input(inputs[0])
                    _stats.calls += 1

            def post_hook(_module, _inputs, output, _name=name, _stats=stat):
                if isinstance(output, torch.Tensor):
                    _stats.update_output(output)

            handles.append(module.register_forward_pre_hook(pre_hook))
            handles.append(module.register_forward_hook(post_hook))

    if not stats:
        raise RuntimeError("No eligible nn.Linear/nn.Conv2d modules were found.")

    model.eval()
    processed = 0
    try:
        with torch.no_grad():
            for batch in calibration_loader:
                images = batch[0] if isinstance(batch, (tuple, list)) else batch
                model(images.to(device, non_blocking=True))
                processed += 1
                if max_batches > 0 and processed >= max_batches:
                    break
    finally:
        for handle in handles:
            handle.remove()

    unobserved = [name for name, item in stats.items()
                  if item.calls == 0 or not math.isfinite(item.input_min)
                  or not math.isfinite(item.output_min)]
    if unobserved:
        preview = ", ".join(unobserved[:12])
        raise RuntimeError(
            f"Calibration did not observe {len(unobserved)} selected module(s): {preview}"
        )
    return stats


def convert_to_static_ptq(
    fp32_model: nn.Module,
    stats: Dict[str, RangeStats],
    modules_to_quantize: Tuple[str, ...] = ("linear", "conv2d"),
) -> Tuple[nn.Module, Dict[str, dict]]:
    """Deep-copy FP32 model and replace calibrated Linear/Conv2d modules."""
    model = copy.deepcopy(fp32_model).cpu().eval()
    specs: Dict[str, dict] = {}
    selected_types = []
    if "linear" in modules_to_quantize:
        selected_types.append(nn.Linear)
    if "conv2d" in modules_to_quantize:
        selected_types.append(nn.Conv2d)

    def recurse(parent: nn.Module, prefix: str = "") -> None:
        for child_name, child in list(parent.named_children()):
            full_name = f"{prefix}.{child_name}" if prefix else child_name
            if isinstance(child, tuple(selected_types)):
                if full_name in FP32_MODULE_NAMES:
                    continue
                if isinstance(child, nn.Conv2d) and child.padding_mode != "zeros":
                    continue
                if full_name not in stats:
                    raise KeyError(f"Missing calibration range for module {full_name!r}.")
                stat = stats[full_name]
                if isinstance(child, nn.Linear):
                    replacement = PTQLinear(child, stat)
                    kind = "Linear"
                elif isinstance(child, nn.Conv2d):
                    replacement = PTQConv2d(child, stat)
                    kind = "Conv2d"
                else:
                    continue
                setattr(parent, child_name, replacement)
                specs[full_name] = {
                    "type": kind,
                    "calls": int(stat.calls),
                    "input_min": float(stat.input_min),
                    "input_max": float(stat.input_max),
                    "output_min": float(stat.output_min),
                    "output_max": float(stat.output_max),
                    "input_scale": float(replacement.input_scale),
                    "input_zero_point": int(replacement.input_zero_point),
                    "output_scale": float(replacement.out_scale),
                    "output_zero_point": int(replacement.out_zero_point),
                }
            else:
                recurse(child, full_name)

    recurse(model)
    if not specs:
        raise RuntimeError("No modules were converted to static PTQ.")
    return model, specs


def count_logical_parameters(model: nn.Module) -> int:
    """Count quantized operator weights plus all remaining FP32 parameters."""
    total = 0
    quantized_ops = set()
    for module in model.modules():
        if isinstance(module, (PTQLinear, PTQConv2d)):
            qop = module.quantized_op
            quantized_ops.add(id(qop))
            total += int(qop.weight().numel())
            bias = qop.bias()
            if bias is not None:
                total += int(bias.numel())
    for module in model.modules():
        if id(module) in quantized_ops:
            continue
        for parameter in module.parameters(recurse=False):
            total += int(parameter.numel())
    return total


def state_tensor_bytes(model: nn.Module) -> int:
    # Quantized Linear/Conv2d state_dicts store packed weights as tuples, which
    # a simple state_dict tensor walk misses. Count those explicitly, then the
    # remaining ordinary floating-point parameters and buffers.
    total = 0
    quantized_modules = (PTQLinear, PTQConv2d)
    for module in model.modules():
        if isinstance(module, quantized_modules):
            weight = module.quantized_op.weight()
            total += weight.numel() * weight.element_size()
            if weight.qscheme() in (torch.per_channel_affine, torch.per_channel_symmetric,
                                    torch.per_channel_affine_float_qparams):
                scales = weight.q_per_channel_scales()
                zero_points = weight.q_per_channel_zero_points()
                total += scales.numel() * scales.element_size()
                total += zero_points.numel() * zero_points.element_size()
            bias = module.quantized_op.bias()
            if bias is not None:
                total += bias.numel() * bias.element_size()
    quantized_op_ids = {
        id(module.quantized_op)
        for module in model.modules()
        if isinstance(module, quantized_modules)
    }
    for module in model.modules():
        if id(module) in quantized_op_ids:
            continue
        for value in list(module.parameters(recurse=False)) + list(module.buffers(recurse=False)):
            total += value.numel() * value.element_size()
    return int(total)


def evaluate_logits(model: nn.Module, images: torch.Tensor) -> torch.Tensor:
    result = model(images)
    if isinstance(result, (tuple, list)):
        logits = result[0]
    else:
        logits = result
    if not isinstance(logits, torch.Tensor) or logits.ndim != 2:
        raise RuntimeError(
            "ProtoPFormer evaluation must return class logits shaped [batch, classes]."
        )
    return logits


def evaluate_fp32_and_ptq(
    fp32_model: nn.Module,
    ptq_model: nn.Module,
    validation_loader: Iterable,
    fp32_device: torch.device,
    agreement_samples: int = 128,
) -> dict:
    """Compare full validation accuracy and top-1 agreement (PTQ runs on CPU)."""
    fp32_model.eval().to(fp32_device)
    ptq_model.eval().cpu()

    total = 0
    fp32_correct = 0
    ptq_correct = 0
    fp32_top5 = 0
    ptq_top5 = 0
    agreement = 0
    subset_total = 0
    subset_agreement = 0
    subset_fp32_correct = 0
    subset_ptq_correct = 0
    max_abs_logit_diff = 0.0
    sum_abs_logit_diff = 0.0
    diff_elements = 0

    with torch.no_grad():
        for batch in validation_loader:
            images, targets = batch[0], batch[1]
            float_logits = evaluate_logits(fp32_model, images.to(fp32_device)).float().cpu()
            ptq_logits = evaluate_logits(ptq_model, images.cpu()).float().cpu()
            if float_logits.shape != ptq_logits.shape:
                raise RuntimeError(
                    f"FP32/PTQ output shape mismatch: {float_logits.shape} vs {ptq_logits.shape}"
                )
            float_pred = float_logits.argmax(dim=1)
            ptq_pred = ptq_logits.argmax(dim=1)
            targets = targets.cpu().long()
            batch_size = int(targets.numel())
            total += batch_size
            fp32_correct += int((float_pred == targets).sum().item())
            ptq_correct += int((ptq_pred == targets).sum().item())
            topk = min(5, int(float_logits.shape[1]))
            fp32_top5 += int((float_logits.topk(topk, dim=1).indices == targets[:, None]).any(dim=1).sum().item())
            ptq_top5 += int((ptq_logits.topk(topk, dim=1).indices == targets[:, None]).any(dim=1).sum().item())
            agreement += int((float_pred == ptq_pred).sum().item())

            compare_n = min(batch_size, max(0, agreement_samples - subset_total))
            if compare_n:
                subset_total += compare_n
                subset_agreement += int((float_pred[:compare_n] == ptq_pred[:compare_n]).sum().item())
                subset_fp32_correct += int((float_pred[:compare_n] == targets[:compare_n]).sum().item())
                subset_ptq_correct += int((ptq_pred[:compare_n] == targets[:compare_n]).sum().item())
                diffs = (float_logits[:compare_n] - ptq_logits[:compare_n]).abs()
                max_abs_logit_diff = max(max_abs_logit_diff, float(diffs.max().item()))
                sum_abs_logit_diff += float(diffs.sum().item())
                diff_elements += int(diffs.numel())

    if total == 0:
        raise RuntimeError("Validation loader yielded no samples.")
    pct = lambda value, denom: 100.0 * value / denom if denom else 0.0
    fp32_acc = pct(fp32_correct, total)
    ptq_acc = pct(ptq_correct, total)
    subset_fp32_acc = pct(subset_fp32_correct, subset_total)
    subset_ptq_acc = pct(subset_ptq_correct, subset_total)
    return {
        "num_validation_samples": total,
        "fp32_top1_accuracy_pct": fp32_acc,
        "ptq_top1_accuracy_pct": ptq_acc,
        "fp32_top5_accuracy_pct": pct(fp32_top5, total),
        "ptq_top5_accuracy_pct": pct(ptq_top5, total),
        "full_validation_top5_accuracy_drop_pp": pct(fp32_top5, total) - pct(ptq_top5, total),
        "full_validation_accuracy_drop_pp": fp32_acc - ptq_acc,
        "full_validation_top1_agreement_pct": pct(agreement, total),
        "agreement_subset_samples": subset_total,
        "subset_fp32_top1_accuracy_pct": subset_fp32_acc,
        "subset_ptq_top1_accuracy_pct": subset_ptq_acc,
        "subset_accuracy_drop_pp": subset_fp32_acc - subset_ptq_acc,
        "subset_top1_agreement_pct": pct(subset_agreement, subset_total),
        "subset_max_abs_logit_diff": max_abs_logit_diff,
        "subset_mean_abs_logit_diff": sum_abs_logit_diff / diff_elements if diff_elements else 0.0,
    }


def rebuild_static_ptq_model(base_model: nn.Module, specs: Dict[str, dict]) -> nn.Module:
    """Rebuild the PTQ module structure from the saved per-module specs.

    `base_model` is a freshly constructed FP32 ProtoPFormer with the same configuration (its weights are
    irrelevant: they are overwritten by load_state_dict). Activation scales / zero points are re-derived from
    the recorded calibration ranges, so only a state_dict has to be stored. This avoids pickling whole
    torch.ao quantized modules, which cannot be restored for Conv2d (their __setstate__ never calls
    nn.Module.__init__).
    """
    if not specs:
        raise ValueError("The artifact contains no module specs.")
    stats: Dict[str, RangeStats] = {}
    for name, spec in specs.items():
        stat = RangeStats()
        stat.input_min = float(spec["input_min"])
        stat.input_max = float(spec["input_max"])
        stat.output_min = float(spec["output_min"])
        stat.output_max = float(spec["output_max"])
        stat.calls = int(spec.get("calls", 1))
        stats[name] = stat
    type_map = {"Linear": "linear", "Conv2d": "conv2d"}
    unknown_types = sorted({spec.get("type") for spec in specs.values()} - set(type_map))
    if unknown_types:
        raise ValueError(f"Unsupported PTQ module types in artifact: {unknown_types}")
    modules = tuple(sorted({type_map[spec["type"]] for spec in specs.values()}))
    model, rebuilt = convert_to_static_ptq(base_model, stats, modules)
    missing = set(specs) ^ set(rebuilt)
    if missing:
        raise RuntimeError(f"Rebuilt PTQ structure differs from the artifact specs: {sorted(missing)[:8]}")
    return model.eval()
