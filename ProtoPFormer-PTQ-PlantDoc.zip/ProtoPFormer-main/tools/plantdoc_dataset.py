"""PlantDoc class-folder dataset with stable split validation."""
from pathlib import Path
from torchvision.datasets import ImageFolder

class PlantDoc(ImageFolder):
    def __init__(self, root, train=True, transform=None):
        root=Path(root).expanduser()
        train_dir=next((root/x for x in ('train','training') if (root/x).is_dir()), None)
        val_dir=next((root/x for x in ('test','val','validation') if (root/x).is_dir()), None)
        if train_dir is None or val_dir is None:
            raise FileNotFoundError(f'Expected train/training and test/val/validation folders under {root}')
        a=sorted(x.name for x in train_dir.iterdir() if x.is_dir())
        b=sorted(x.name for x in val_dir.iterdir() if x.is_dir())
        if not a or a != b:
            raise ValueError(f'PlantDoc split classes differ; train={a}, validation={b}')
        super().__init__(str(train_dir if train else val_dir), transform=transform)
        self.num_classes=len(self.classes)
