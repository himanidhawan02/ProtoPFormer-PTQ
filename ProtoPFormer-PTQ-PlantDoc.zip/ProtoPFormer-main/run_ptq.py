#!/usr/bin/env python3
"""Calibrate, evaluate, and export hybrid static INT8 PTQ for ProtoPFormer.

Calibration and validation use the dataset classes already supported by
``tools.datasets``. The FP32 training checkpoint is never modified.
"""
from __future__ import annotations

import argparse
import copy
import json
import random
import time
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader

import protopformer
from tools.datasets import build_dataset, build_transform
from tools.ptq_static import (
    calibrate_module_ranges, choose_quantized_engine, convert_to_static_ptq,
    count_logical_parameters, evaluate_fp32_and_ptq, state_tensor_bytes,
)


def parse_args():
    parser = argparse.ArgumentParser(description="Calibrated hybrid INT8 PTQ for ProtoPFormer")
    parser.add_argument("--checkpoint", required=True, help="FP32 epoch-best.pth checkpoint")
    parser.add_argument("--data_set", default="", help="Override dataset name saved in checkpoint args")
    parser.add_argument("--data_path", default="", help="Override dataset root saved in checkpoint args")
    parser.add_argument("--train_dir", default="", help="Optional CUB2011 training ImageFolder path")
    parser.add_argument("--test_dir", default="", help="Optional CUB2011 validation ImageFolder path")
    parser.add_argument("--output_dir", default="output_ptq")
    parser.add_argument("--calibration_batches", type=int, default=32,
                        help="Maximum batches from training split used for calibration; 0 means all")
    parser.add_argument("--calibration_batch_size", type=int, default=16)
    parser.add_argument("--val_batch_size", type=int, default=32)
    parser.add_argument("--num_workers", type=int, default=4)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu",
                        help="Device for FP32 calibration/reference; exported quantized model runs on CPU")
    parser.add_argument("--engine", default="", help="Quantized engine override (x86/fbgemm/onednn/qnnpack)")
    parser.add_argument("--modules", default="linear,conv2d", help="Comma-separated: linear,conv2d")
    parser.add_argument("--agreement_samples", type=int, default=128)
    parser.add_argument("--seed", type=int, default=1028)
    return parser.parse_args()


def get_arg(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def model_kwargs(saved):
    architecture = get_arg(saved, "base_architecture")
    proto_shape = get_arg(saved, "prototype_shape")
    if architecture is None or proto_shape is None:
        raise ValueError("Checkpoint args must include base_architecture and prototype_shape.")
    return dict(
        base_architecture=architecture,
        img_size=get_arg(saved, "img_size", 224), prototype_shape=list(proto_shape),
        num_classes=int(get_arg(saved, "nb_classes", 120)),
        reserve_layers=list(get_arg(saved, "reserve_layers", [])),
        reserve_token_nums=list(get_arg(saved, "reserve_token_nums", [])),
        use_global=bool(get_arg(saved, "use_global", False)),
        use_ppc_loss=bool(get_arg(saved, "use_ppc_loss", False)),
        ppc_cov_thresh=float(get_arg(saved, "ppc_cov_thresh", 1.0)),
        ppc_mean_thresh=float(get_arg(saved, "ppc_mean_thresh", 2.0)),
        global_coe=float(get_arg(saved, "global_coe", 0.5)),
        global_proto_per_class=int(get_arg(saved, "global_proto_per_class", 10)),
        prototype_activation_function=get_arg(saved, "prototype_activation_function", "log"),
        add_on_layers_type=get_arg(saved, "add_on_layers_type", "bottleneck"),
    )


def build_model(checkpoint):
    if "model" not in checkpoint or "args" not in checkpoint:
        raise KeyError("Checkpoint must contain the original 'model' and 'args' entries.")
    saved = checkpoint["args"]
    model = protopformer.construct_PPNet(pretrained=False, **model_kwargs(saved))
    state = checkpoint["model"]
    if state and all(str(k).startswith("module.") for k in state):
        state = {str(k)[7:]: v for k, v in state.items()}
    model.load_state_dict(state, strict=True)
    return model.eval(), saved


def make_dataset_args(saved, cli):
    values = dict(saved) if isinstance(saved, dict) else vars(saved).copy()
    values["data_set"] = cli.data_set or values.get("data_set")
    values["data_path"] = cli.data_path or values.get("data_path")
    values["input_size"] = values.get("input_size", values.get("img_size", 224))
    values["model"] = values.get("model", values.get("base_architecture", "deit_tiny_patch16_224"))
    values["train_dir"] = cli.train_dir or values.get("train_dir", "")
    values["test_dir"] = cli.test_dir or values.get("test_dir", "")
    if not values["data_set"] or not values["data_path"]:
        raise ValueError("Dataset name/root must be in checkpoint args or passed with --data_set/--data_path.")
    return argparse.Namespace(**values)


def safe_json(value):
    if isinstance(value, dict):
        return {str(k): safe_json(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe_json(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, torch.Tensor):
        return value.item() if value.numel() == 1 else value.tolist()
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


def main():
    args = parse_args()
    set_seed(args.seed)
    checkpoint_path = Path(args.checkpoint).expanduser().resolve()
    output = Path(args.output_dir).expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    if not checkpoint_path.is_file():
        raise FileNotFoundError(checkpoint_path)
    modules = tuple(x.strip().lower() for x in args.modules.split(",") if x.strip())
    if not modules or not set(modules).issubset({"linear", "conv2d"}):
        raise ValueError("--modules accepts linear and/or conv2d")
    if args.calibration_batches < 0:
        raise ValueError("--calibration_batches must be >= 0")
    engine = choose_quantized_engine(args.engine or None)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested, but unavailable.")

    try:
        checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    except TypeError:  # PyTorch versions before weights_only was introduced
        checkpoint = torch.load(checkpoint_path, map_location="cpu")
    fp32, saved_args = build_model(checkpoint)
    dataset_args = make_dataset_args(saved_args, args)

    # Keep the training split for calibration, but replace stochastic training
    # augmentation with the repository's deterministic evaluation transform.
    calibration_set, _ = build_dataset(True, dataset_args)
    calibration_set.transform = build_transform(False, dataset_args)
    validation_set, _ = build_dataset(False, dataset_args)
    calibration_loader = DataLoader(
        calibration_set, batch_size=args.calibration_batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=device.type == "cuda", drop_last=False,
        generator=torch.Generator().manual_seed(args.seed),
    )
    validation_loader = DataLoader(
        validation_set, batch_size=args.val_batch_size, shuffle=False,
        num_workers=args.num_workers, pin_memory=device.type == "cuda", drop_last=False,
    )

    print("Dataset:", dataset_args.data_set, "| FP32 device:", device, "| quantized engine:", engine)
    print("Calibration images:", len(calibration_set), "| validation images:", len(validation_set))
    print("Quantizing module types:", modules)
    fp32.to(device).eval()
    start = time.time()
    ranges = calibrate_module_ranges(fp32, calibration_loader, device, args.calibration_batches, modules)
    print("Calibrated", len(ranges), "modules in", round(time.time() - start, 1), "seconds")

    fp32_state = {k: v.detach().cpu() for k, v in fp32.state_dict().items()}
    fp32_state_file = output / "fp32_model_state_dict.pth"
    torch.save(fp32_state, fp32_state_file)
    fp32_bytes = sum(v.numel() * v.element_size() for v in fp32_state.values())
    fp32_params = sum(p.numel() for p in fp32.parameters())

    ptq, specs = convert_to_static_ptq(fp32, ranges, modules)
    metrics = evaluate_fp32_and_ptq(fp32, ptq, validation_loader, device, args.agreement_samples)
    ptq_state_file = output / "ptq_model_state_dict.pth"
    torch.save(ptq.state_dict(), ptq_state_file)
    engine_file = output / "quantized_engine.txt"
    engine_file.write_text(engine + "\n")
    artifact = output / "protopformer_ptq_int8.pth"
    torch.save({
        "format": "protopformer_static_ptq_hybrid_int8_v2",
        "model_state": ptq.state_dict(),     # state_dict + specs; the module object itself is NOT pickled
        "model_config": {
            "construct_kwargs": model_kwargs(saved_args),
            "base_architecture": get_arg(saved_args, "base_architecture"),
            "prototype_shape": list(get_arg(saved_args, "prototype_shape")),
            "num_classes": int(get_arg(saved_args, "nb_classes", 120)),
            "data_set": dataset_args.data_set,
            "img_size": int(get_arg(saved_args, "img_size", 224)),
            "input_size": int(get_arg(saved_args, "input_size", get_arg(saved_args, "img_size", 224))),
            "use_global": bool(get_arg(saved_args, "use_global", False)),
        },
        "quantization": {
            "method": "calibrated post-training static quantization",
            "activation_dtype": "quint8", "weight_dtype": "qint8",
            "weight_granularity": "per-output-channel symmetric",
            "activation_granularity": "per-module per-tensor affine",
            "engine": engine, "quantized_modules": list(modules),
            "calibration_batches_limit": args.calibration_batches,
            "calibration_batch_size": args.calibration_batch_size,
            "calibration_images": len(calibration_set), "module_specs": specs,
            "fp32_modules": ["last_layer", "last_layer_global"],
            "remaining_fp32_ops": ["prototype distance/similarity", "attention softmax and LayerNorm", "residual and unsupported operations"],
        },
        "metrics": metrics,
    }, artifact)

    fp32_file_bytes = fp32_state_file.stat().st_size
    ptq_file_bytes = ptq_state_file.stat().st_size
    ptq_bytes = state_tensor_bytes(ptq)
    size = {
        "fp32_logical_parameters": int(fp32_params),
        "ptq_logical_parameters": count_logical_parameters(ptq),
        "fp32_state_tensor_bytes": int(fp32_bytes),
        "ptq_state_tensor_bytes": int(ptq_bytes),
        "state_tensor_size_reduction_pct": 100.0 * (1.0 - ptq_bytes / max(fp32_bytes, 1)),
        "state_tensor_compression_ratio": fp32_bytes / max(ptq_bytes, 1),
        "fp32_state_dict_file_bytes": fp32_file_bytes,
        "ptq_state_dict_file_bytes": ptq_file_bytes,
        "state_dict_file_size_reduction_pct": 100.0 * (1.0 - ptq_file_bytes / max(fp32_file_bytes, 1)),
        "ptq_full_artifact_file_bytes": artifact.stat().st_size,
    }
    results = {
        "checkpoint": str(checkpoint_path), "dataset": dataset_args.data_set,
        "data_path": str(dataset_args.data_path), "quantization_engine": engine,
        "quantized_module_count": len(specs),
        "calibration_ranges": {name: vars(stat) for name, stat in ranges.items()},
        "verification": metrics, "model_size": size, "artifact": str(artifact),
    }
    results_path = output / "ptq_results.json"
    results_path.write_text(json.dumps(safe_json(results), indent=2))
    print("\nFP32 vs PTQ validation:")
    for key, value in metrics.items():
        print(f"  {key}: {value}")
    print("\nState tensor sizes (MiB): FP32 %.3f | PTQ %.3f | reduction %.2f%%" % (
        fp32_bytes / 1024**2, ptq_bytes / 1024**2, size["state_tensor_size_reduction_pct"]))
    print("Serialized state_dict sizes (MiB): FP32 %.3f | PTQ %.3f" % (
        fp32_file_bytes / 1024**2, ptq_file_bytes / 1024**2))
    print("Saved PTQ model:", artifact)
    print("Saved metrics:", results_path)


if __name__ == "__main__":
    main()
