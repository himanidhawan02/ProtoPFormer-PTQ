# ProtoPFormer

## Introduction

This is the official implementation of paper **"ProtoPFormer: Concentrating on Prototypical Parts in Vision Transformers for
Interpretable Image Recognition"**. [**[Paper](https://arxiv.org/abs/2208.10431)**]

The overview of ProtoPFormer is as below:

![img](./imgs/method.svg)

## Updates

* **09/27/2022** The supplementary material has been added in the Arxiv preprint.
* **09/18/2022** Modify the default backbone to be `deit_tiny_patch16_224`.
* **08/29/2022** The citation of our paper has been added.
* **08/23/2022** Code has been uploaded.

## Dataset
The CUB dataset is downloaded from `https://www.vision.caltech.edu/datasets/cub_200_2011/`.

The Stanford Dogs dataset is downloaded from `http://vision.stanford.edu/aditya86/ImageNetDogs/`.

The Stanford Cars dataset is downloaded from `http://ai.stanford.edu/~jkrause/cars/car_dataset.html`.

Decompress them and place them in the `datasets/` folder as follows:

```
datasets
--CUB_200_2011
    |--attributes
    |--images
    |--parts
    |...
--stanford_dogs
    |--Annotation
    |--Images
    |...
--stanford_cars
    |--cars_test
    |--cars_train
    |...
```

## Usage

First clone the repository locally:

```
git clone git@github.com:zju-vipa/ProtoPFormer.git
```

Then install the requried packages as below:

```
pytorch==1.8.1
torchvision==0.9.1
pillow==9.1.1
timm==0.5.4
opencv-python==4.6.0.66
tensorboard==2.9.1
scipy==1.8.1
pandas==1.4.3
matplotlib==3.5.2
scikit-learn==1.1.1
```

Newer versions of these packages may work.

## Train

The training scripts for CUB, Dogs and Cars are `scripts/train_cub.sh`, `scripts/train_dogs.sh`, `scripts/train_car.sh`, respectively.

The format instruction of training is as below:

```
sh scripts/train_cub.sh $backbone $batch_size $num_gpus
```

Here, `$backbone` is chosen from [`deit_tiny_patch16_224`, `deit_small_patch16_224`, `cait_xxs24_224`], `$batch_size` denotes batch size, and `$num_gpus` denotes the number of gpus for training. An example for training a ProtoPFormer of backbone `deit_tiny_patch16_224` on CUB with batch size 64 and 2 gpus is as below:

```
sh scripts/train_cub.sh deit_tiny_patch16_224 64 2
```

## Visualize

The format instruction of training is as below:

```
sh scripts/visualize.sh $backbone $data_set $output_dir $use_gauss $modeldir $modelfile
```

An example for visualizing a ProtoPFormer of backbone `deit_tiny_patch16_224` on CUB with a checkpoint file `output_cosine/CUB2011U/deit_tiny_patch16_224/1028--adamw-0.05-200-protopformer/checkpoints/epoch-best.pth` is as below:

```
sh scripts/visualize.sh deit_tiny_patch16_224 \
CUB2011U \
output_view \
False \
output_cosine/CUB2011U/deit_tiny_patch16_224/1028--adamw-0.05-200-protopformer/checkpoints \
epoch-best.pth
```

Noted that `$use_gauss` denotes whether visualizing gaussian shape, it will be much slower if `$use_gauss` is True.

## Post-training quantization (PTQ)

The recommended path is **calibrated hybrid static INT8 PTQ**. It quantizes supported `nn.Linear` and zero-padding `nn.Conv2d` modules using per-output-channel symmetric INT8 weights and per-module calibrated activation ranges. The final `last_layer` and `last_layer_global` class projections stay in FP32 so the class logits are not rounded to calibrated INT8 output steps. Other quantized module outputs are dequantized at module boundaries. Feature maps between modules, Sigmoid operations, prototype vectors, distance/similarity calculations, attention softmax, LayerNorm, residual math, and unsupported operators remain FP32. This is a hybrid PTQ baseline, not an all-integer feature-map model, so compare it with integer-feature QAT only when the quantized scope is clearly accounted for. Calibration does not update trained weights.

The workflow uses the dataset implementation already in `tools/datasets.py`. It calibrates on a deterministic, non-augmented view of the training split and evaluates on the dataset's validation/test split. The data name and root are taken from the checkpoint arguments unless overridden. Calibration currently uses observed per-module min/max ranges, so representative calibration images matter and outliers can reduce accuracy. The default is 512 calibration images; compare larger calibration sets and multiple `--seed` values if results are sensitive to the sampled images. It reports FP32 and PTQ top-1/top-5 accuracy, top-1 agreement, logit differences, model state sizes, compression ratio, calibration ranges, and saves both the full PTQ artifact and comparison state dictionaries. Deployment CPU latency is not measured; benchmark accuracy and speed on the target machine and selected quantized engine before deployment.

```bash
python run_ptq.py \
  --checkpoint output_cosine/CUB2011U/deit_tiny_patch16_224/run/checkpoints/epoch-best.pth \
  --output_dir output_ptq \
  --calibration_batches 32 --calibration_batch_size 16 \
  --val_batch_size 32 --modules linear,conv2d
```

For checkpoints without dataset arguments, provide `--data_set` and `--data_path`. For the `CUB2011` ImageFolder option, `--train_dir` and `--test_dir` can override its image directories. Use `--device cpu` if CUDA is unavailable. The quantized artifact runs on CPU. Choose calibration images from the training split; validation data is used only for comparison. Check the reported validation metrics before using the artifact.

The output directory contains `protopformer_ptq_int8.pth`, `ptq_model_state_dict.pth`, `fp32_model_state_dict.pth`, `ptq_results.json`, and `quantized_engine.txt`. The v2 artifact stores a state dictionary, model construction settings, and calibration specs. The model structure is rebuilt before loading its state, avoiding pickling native quantized Conv2d modules. Artifacts from the earlier v1 format cannot be reloaded; rerun `run_ptq.py` to create a v2 artifact. File-size reduction and accuracy are architecture- and checkpoint-dependent; the script reports measured values for the provided data.

Use the same artifact for CPU inference through the repository evaluation entry point. Keep the artifact beside its `quantized_engine.txt` file and pass the same dataset root used during calibration:

```bash
python main.py \
  --eval --device cpu \
  --ptq_artifact output_ptq/protopformer_ptq_int8.pth \
  --data_set CUB2011U --data_path datasets/CUB_200_2011/ \
  --input_size 224 --batch_size 32 --output_dir output_ptq_eval
```

`main.py` rebuilds the static quantized modules from the artifact's module specs, loads the state dictionary, and validates the artifact format, quantized backend, dataset name, class count, and input size before evaluation. Static PTQ is the only quantization and quantized-artifact format provided in this repository; the ordinary `main.py --eval --resume ...` path remains the FP32 checkpoint evaluation path.

The model's PPC loss, prototype helper, and attention rollout paths create tensors on the active tensor's device, so CPU inference does not rely on hard-coded CUDA allocations.

## Evaluating Interpretability

We borrow the evaluation code from [EvalProtoPNet](https://github.com/hqhQAQ/EvalProtoPNet) to evaluate the interpretability score of ProtoPFormer.

```
python eval_interpretability.py \
--gpuid=0 \
--base_architecture=deit_tiny_patch16_224 \
--reserve_layers=11 \
--data_path=datasets/CUB_200_2011/ \
--prototype_shape 2000 192 1 1 \
--use_global=True \
--global_proto_per_class=10 \
--resume=output_cosine/CUB2011U/deit_tiny_patch16_224/1028--adamw-0.05-200-protopformer/checkpoints/epoch-best.pth \
--global_coe=0.5 \
--reserve_token_nums=81 \
--use_ppc_loss=True \
--batch_size=32 \
--out_dir=output_view
```

The below table shows that ProtoPFormer significantly improves the interpretability score of ProtoPNet on vision transformers.

| Method & Backbone | DeiT-Ti | DeiT-S | CaiT-XXS |
| :-----: | :-----: | :-----: | :-----: |
| ProtoPNet | 3.75 | 0.05 | 42.55 |
| ProtoPFormer | **82.65** | **31.30** | **71.45** |

## Citation
If you find our code is helpful for your research, please cite:

```
@article{xue2022protopformer,
  title={ProtoPFormer: Concentrating on Prototypical Parts in Vision Transformers for Interpretable Image Recognition},
  author={Xue, Mengqi and Huang, Qihan and Zhang, Haofei and Cheng, Lechao and Song, Jie and Wu, Minghui and Song, Mingli},
  journal={arXiv preprint arXiv:2208.10431},
  year={2022}
}
```


## Statement

This project is for research purpose only. For any other questions please contact `mqxue@zju.edu.cn`.
